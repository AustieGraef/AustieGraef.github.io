// Debug options to show in test extension
function checkCodecs(rtcPeerConnection) {
  rtcPeerConnection.addEventListener("icegatheringstatechange", (event) => {
    let codecList = null;
    if (rtcPeerConnection.iceGatheringState === "complete") {
      const receivers = rtcPeerConnection.getReceivers();
      receivers.forEach((receiver) => {
        if (receiver.track && receiver.track.kind === "video") {
          codecList = receiver.getParameters().codecs;
        } else {
          console.log("Sender=" + JSON.stringify(receiver));
        }
      });
    }
    console.log("Available codecs are=" + JSON.stringify(codecList));
  })
}
let lastResult;
function gatherStats(rtcPeerConnection) {
  if (!rtcPeerConnection) {
    console.error("No connection");
    return;
  }
  statsTimer = setInterval(function () {
    if (!rtcPeerConnection) {
      console.log("NO RTC CONNECTION");
      return;
    }
    const receiver = rtcPeerConnection.getReceivers()[0];
    if (!receiver) {
      console.log("NO RECEIVER");
      return;
    }
    const settings = receiver.track.getSettings();
    receiver.getStats().then(res => {
      res.forEach(report => {
        let bytes;
        if (report.type === 'inbound-rtp') {
          if (report.isRemote) {
            return;
          }
          const now = report.timestamp;
          bytes = report.bytesReceived;
          if (lastResult && lastResult.has(report.id)) {
            const bitrate = 8 * (bytes - lastResult.get(report.id).bytesReceived) /
                (now - lastResult.get(report.id).timestamp);
            console.log("Bitrate=" + bitrate + " Width=" + settings.width + " Height=" + settings.height);
          }
        }
      });
      lastResult = res;
    });
  }, 5000);
}